Name: Gordon Wu

Completeness: 80%

Functionality: 
     - letters are selected randomly and added to the tile rack
     - letters are able to be dragged and dropped onto the board or the rack
     - bonus squares are visible and 
     -  **NOT COMPLETE** the score isn't tallied correctly per word; however it does keep up after each word
     
     - any number of words are able to be played until the user wants to quit
     - the board is cleared after each round
     - the correct amount of letter tiles are added back into the user's hand after
       a round is done
     - the score is tallied per round / word

     - the high score is tallied throughout the game

     - the source code is fully commented and pertinent contact info is visible

     Extra Credit
     - ** NOT COMPLETE ** attempted to start to get dictionary data
     